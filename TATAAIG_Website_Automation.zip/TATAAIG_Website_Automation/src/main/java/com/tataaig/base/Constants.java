package com.tataaig.base;

public class Constants {
	
	
	//Configuration
	public static final String browser = "chrome";
	public static final String testsiteurl = "https://www.tataaig.com/";
	public static long implicitwait=10;
	public static long explicitwait=10;
	
	//locators
	

}
